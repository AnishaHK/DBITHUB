<?php
$conn=mysqli_connect("127.0.0.1","shraddha_contact","contact","shraddha_contact");
$sql="SELECT * FROM iandi";
$result=mysqli_query($conn,$sql);









?>
<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
}

table {
  width: 100%;
}
</style>
</head>
<body>

<h2>Full-width Table</h2>

<table>
  <tr>
    <th>name</th>
    <th>email</th>
    <th>number</th>
    <th>usn</th>
    <th>branch</th>
    <th>year</th>
  </tr>



  <?php
while($row=mysqli_fetch_array($result)){







?>
  <tr>
    <td><?php echo $row["name"];?></td>
    <td><?php echo $row["email"];?></td>
    <td><?php echo $row["number"];?></td>
    <td><?php echo $row["usn"];?></td>
    <td><?php echo $row["branch"];?></td>
    <td><?php echo $row["year"];?></td>
    
    
  </tr>
<?php
}

?>
 
</table>

</body>
</html>



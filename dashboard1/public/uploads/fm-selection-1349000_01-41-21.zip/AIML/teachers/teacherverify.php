<?php
$conn=mysqli_connect("localhost","root","","aiml");
$id=$_POST["id"];
$password=$_POST["password"];
$query="SELECT * FROM teachers";
$result=mysqli_query($conn,$query);

    if($id=="18mat31_arun" && $password=="arun@123")
    {
        header("Location:arunportal.php");
        session_start();
        $_SESSION["id"]=$row["id"];
        $_SESSION["password"]=$row["password"];

    }
else{
    ?>
<script>
    alert("invalid credentials");
    window.location.href = "index.html";
    </script>

<?php
}



















?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
</head>
<body>
    <h1><center>Hello Arun</center></h1>
    <form action="" method="POST">
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">USN</th>
      <th scope="col">Marks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>




    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>




    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>




    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>




    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>


    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>




    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>




    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>




    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>



    <tr>
      <th scope="row">1</th>
      <td>Abhi</td>
      <td>1DB20CI001</td>
      <td><input type="text" name="n1"></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Akash</td>
      <td>1DB20CI002</td>
      <td><input type="text" name="n2"></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Ani</td>
      <td>1DB20CI003</td>
      <td><input type="text" name="n3"></td>
    </tr>


  </tbody>

</table>
<button name="submit">submit</button>
</form>

</body>
</html>


<?php
include("conn.php");
if(isset($_POST["submit"])){
$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);




$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);





$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);




$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);




$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);





$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);





$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);





$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);





$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);




$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);





$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);




$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);




$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);





$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);



$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);






$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);




$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);




$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);






$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);







$n1=$_POST["n1"];
$n2=$_POST["n2"];
$n3=$_POST["n3"];
$sql1="UPDATE iamarks1 SET m3=$n1  WHERE usn='1db20ci001'"   ;
mysqli_query($conn,$sql1);
$sql2="UPDATE iamarks1 SET m3=$n2  WHERE usn='1db20ci002'"   ;
mysqli_query($conn,$sql2);
$sql3="UPDATE iamarks1 SET m3=$n3  WHERE usn='1db20ci003'"   ;
mysqli_query($conn,$sql3);










}





?>
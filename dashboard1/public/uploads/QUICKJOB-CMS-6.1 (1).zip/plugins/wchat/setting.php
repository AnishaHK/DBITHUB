<?php
/**
 * Wchat - Fully Responsive PHP AJAX Chat Script
 * @author Bylancer
 * @version 1.5
 * @url https://codecanyon.net/item/wchat-fully-responsive-phpajax-chat/18047319
 * @Copyright (c) 2015-18 Devendra Katariya (bylancer.com)
 */

$MySQLi_user_table_name = 'user';
$MySQLi_userid_field    = 'id';
$MySQLi_status_field    = 'status';
$MySQLi_username_field  = 'username';
$MySQLi_password_field  = 'password';
$MySQLi_email_field     = 'email';
$MySQLi_fullname_field  = 'name';
$MySQLi_joined_field    = 'created_at';
$MySQLi_country_field   = 'country';
$MySQLi_about_field     = 'description';
$MySQLi_sex_field       = 'sex';
$MySQLi_dob_field       = 'dob';
$MySQLi_photo_field     = 'image';


?>

<h1><center>IA-1 MARKS</center></h1>
<?php
session_start();
$usn=$_SESSION["usn"];
include_once("conn.php");
$sql="SELECT * FROM iamarks1 WHERE usn='$usn'";



$result=mysqli_query($conn,$sql);




echo "<table border='1' width='100%'>

<tr>

<th>SE</th>

<th>ADE</th>

<th>M3</th>
<th>DMS</th>
<th>DSA</th>
<th>CO</th>




</tr>";

 

while($row = mysqli_fetch_array($result))

  {

  echo "<tr>";

  echo "<td>" . $row['se'] . "</td>";

  echo "<td>" . $row['ade'] . "</td>";

  echo "<td>" . $row['m3'] . "</td>";

  echo "<td>" . $row['dms'] . "</td>";
  echo "<td>" . $row['dsa'] . "</td>";
  echo "<td>" . $row['co'] . "</td>";

  echo "</tr>";

  }

echo "</table>";














?>
















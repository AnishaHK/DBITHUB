<?php
$name=$_POST["name"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$message=$_POST["message"];
$conn=mysqli_connect("127.0.0.1","shraddha_contact","contact","shraddha_contact");
$sql="INSERT INTO contact (name,email,phone,message) VALUES('$name','$email','$phone','$message')";
$query=mysqli_query($conn,$sql);
if($query)
{
    
    ?>
<script>alert("we will get back to you shortly");
window.location.href="index.html";
</script>
    <?php
}









?>
<?php 
$email=$_POST['email'];
include_once("conn.php");

$sql = "INSERT INTO newsletter(email) VALUES('$email')";
$query=mysqli_query($conn,$sql);






?>



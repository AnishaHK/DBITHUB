<?php

include_once("conn.php");
$sql="SELECT * FROM program";
$result=mysqli_query($conn,$sql);









?>
<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
}

table {
  width: 100%;
}
</style>
</head>
<body>

<h2>Coding Registered People</h2>

<table>
  <tr>
    <th>name</th>
    <th>email</th>
    <th>phone</th>
    <th>USN</th>
    <th>Branch</th>
    <th>Year</th>
    <th>Programm</th>
  </tr>



  <?php
while($row=mysqli_fetch_array($result)){







?>
  <tr>
    <td><?php echo $row["name"];?></td>
    <td><?php echo $row["email"];?></td>
    <td><?php echo $row["number"];?></td>
    <td><?php echo $row["usn"];?></td>
    <td><?php echo $row["branch"];?></td>
    <td><?php echo $row["year"];?></td>
    <td><?php echo $row["programming_language"];?></td>
    
  </tr>
<?php
}

?>
 
</table>

</body>
</html>











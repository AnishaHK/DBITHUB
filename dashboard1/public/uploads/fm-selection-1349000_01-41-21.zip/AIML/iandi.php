<?php
$name=$_POST["name"];
$email=$_POST["email"];
$phone=$_POST["number"];
$usn=$_POST["usn"];
$branch=$_POST["branch"];
$year=$_POST["year"];
switch($year)
{
    case 0:
        $year=1;
        break;
    case 1:
        $year=2;
        break;
    case 2:
        $year=3;
        break;
    case 3:
        $year=4;
        break;

}

switch($branch)
{
    case 0:
        $branch="CSE(AI & ML)";
        break;
    case 1:
        $branch="CSE";
        break;
    case 2:
        $branch="ISE";
        break;
    case 3:
        $branch="ECE";
        break;
    case 4:
        $branch="EEE";
        break;
    case 5:
        $branch="TCE";
        break;
    case 6:
        $branch="CIVIL";
        break;
    case 7:
        $branch="MECH";
        break;
    case 8:
        $branch="AI & DS";
        break;



}

include_once("conn.php");
$sql="INSERT INTO iandi(name,email,number,usn,branch,year) VALUES('$name','$email','$phone','$usn','$branch','$year')";
mysqli_query($conn,$sql);

if($sql)
{
    
    ?>
<script>alert("Thank you for Registering ");
window.location.href="index.html";
</script>
    <?php
}










?>
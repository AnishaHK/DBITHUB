<?php
$name=$_POST["name"];
$email=$_POST["email"];
$phone=$_POST["number"];
$usn=$_POST["usn"];
$branch=$_POST["branch"];
$year=$_POST["year"];
$language=$_POST["program"];

switch($year)
{
    case 0:
        $year=1;
        break;
    case 1:
        $year=2;
        break;
    case 2:
        $year=3;
        break;
    case 3:
        $year=4;
        break;

}

switch($branch)
{
    case 0:
        $branch="CSE(AI AND ML)";
        break;
    case 1:
        $branch="CSE";
        break;
    case 2:
        $branch="ECE";
        break;
    case 3:
        $branch="EEE";
        break;
    case 4:
        $branch="TCE";
        break;
    case 5:
        $branch="CIVIL";
        break;
    case 6:
        $branch="MECH";
        break;
    case 7:
        $branch="AI AND DS";
        break;


}

switch($language)
{
    case 0:
        $language="python";
        break;
    case 1:
        $language="Web Development";
        break;
    case 2:
        $language="Java";
        break;
    case 3:
        $language="C/C++";
        break;
    case 4:
        $language="Data Science";
        break;
    case 5:
        $language="Deep Learning";
        break;
    case 6:
        $language="NLP";
        break;
    case 7:
        $language="Neural netorks";
        break;
}

include_once("conn.php");
$sql="INSERT INTO program(name,email,number,usn,branch,year,programming_language) VALUES('$name','$email','$phone','$usn','$branch','$year','$language')";
mysqli_query($conn,$sql);

if($sql)
{
    
    ?>
<script>alert("We will contact you shortly by email");
window.location.href="index.html";
</script>
    <?php
}










?>
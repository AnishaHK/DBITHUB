<?php
$conn=mysqli_connect("localhost","root","","aiml");
$usn=$_POST["usn"];
$password=$_POST["password"];
$query="SELECT * FROM students";
$result=mysqli_query($conn,$query);
while($row=mysqli_fetch_array($result))
{
    if($row["usn"]==$usn && $row["password"]==$password)
    {
        header("Location:studentportal.php");
        session_start();
        $_SESSION["usn"]=$row["usn"];
        $_SESSION["password"]=$row["password"];

    }
else{
    ?>
<script type="text/javascript">
    alert("Invalid Credentials");
    window.location.href = "index.html";
    </script>

<?php
}
}
?>